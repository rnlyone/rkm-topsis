@include('app.app', ['hasil_active' => 'active', 'title' => 'Hasil Akhir'])

<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">
            {{-- directory content --}}
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-start mb-0">Hasil Akhir Kelas {{$kelas->nama}}</h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="/">Home</a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="/hasil">Hasil Akhir</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Dashboard Analytics Start -->
            <section class="app-user-list">

                <div class="card">
                    <div style="margin: 10pt">
                    <div class="card-datatable table-responsive pt-0">
                        <div class="card-header p-0">
                            <div class="head-label"><h5 class="mt-1">Hasil Kelas {{$kelas->nama}}</h5></div>
                        </div>
                        <table class="user-list-table table" id="kelastable">
                            <thead class="table-light">
                                <tr>
                                    <th>Id.</th>
                                    <th>Nama</th>
                                    <th>Tingkat</th>
                                    <th>Rekomendasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($alterdata as $alter)
                                <tr>
                                        <td>{{$alter->id}}</td>
                                        <td>{{$alter->nama}}</td>
                                        <td><span class="
                                            @if ($labelhasil[$alter->kelas][$alter->id] == "Ringan")
                                                badge bg-success
                                            @elseif ($labelhasil[$alter->kelas][$alter->id] == "Sedang")
                                                badge bg-warning
                                            @elseif ($labelhasil[$alter->kelas][$alter->id] == "Berat")
                                                badge bg-danger
                                            @else
                                                badge bg-secondary
                                            @endif
                                            ">{{$labelhasil[$alter->kelas][$alter->id]}}</span></td>
                                        <td>

                                        <span>
                                            @if (strpos($kelas->nama, "Tunanetra")!== false)
                                                @if ($labelhasil[$alter->kelas][$alter->id] == "Ringan")
                                                    MP. Audio Visual
                                                @elseif ($labelhasil[$alter->kelas][$alter->id] == "Sedang")
                                                    MP. Visual
                                                @elseif ($labelhasil[$alter->kelas][$alter->id] == "Berat")
                                                    MP. Audio
                                                @else
                                                Belum ada rekomendasi
                                                @endif
                                            @elseif (strpos($kelas->nama, "Tunarungu")!== false)
                                                @if ($labelhasil[$alter->kelas][$alter->id] == "Ringan")
                                                    MP. Audio
                                                @elseif ($labelhasil[$alter->kelas][$alter->id] == "Sedang")
                                                    MP. Audio Visual
                                                @elseif ($labelhasil[$alter->kelas][$alter->id] == "Berat")
                                                    MP. Visual
                                                @else
                                                Belum ada rekomendasi
                                                @endif
                                            @elseif (strpos($kelas->nama, "Tunadaksa")!== false)
                                                @if ($labelhasil[$alter->kelas][$alter->id] == "Ringan")
                                                    MP. Audio
                                                @elseif ($labelhasil[$alter->kelas][$alter->id] == "Sedang")
                                                    MP. Visual
                                                @elseif ($labelhasil[$alter->kelas][$alter->id] == "Berat")
                                                    MP. Audio Visual
                                                @else
                                                Belum ada rekomendasi
                                                @endif
                                            @elseif (strpos($kelas->nama, "Tunagrahita")!== false)
                                                @if ($labelhasil[$alter->kelas][$alter->id] == "Ringan")
                                                    MP. Audio
                                                @elseif ($labelhasil[$alter->kelas][$alter->id] == "Sedang")
                                                    MP. Visual
                                                @elseif ($labelhasil[$alter->kelas][$alter->id] == "Berat")
                                                    MP. Audio Visual
                                                @else
                                                    Belum ada rekomendasi
                                                @endif
                                            @endif
                                        </span>
                                        </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- Modal to add new user starts-->

                    </div>
                    <!-- Modal to add new user Ends-->
                </div>

        </div>
    </div>
</div>

{{-- MODAL --}}


{{-- MODAL END --}}


<!-- END: Content-->
@include('app.footer')
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script>

    $(document).ready(function(){
        const table = $('.wptable').DataTable({
            searching: false,
            paging: false,
            info: false,
        })
        });
</script>

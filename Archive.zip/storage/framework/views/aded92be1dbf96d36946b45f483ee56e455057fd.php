<?php echo $__env->make('app.app', ['smarter_active' => 'active', 'title' => 'Perhitungan Smarter'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">
            
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-start mb-0">Perhitungan Smarter</h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="/">Home</a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="owa">Perhitungan Smarter</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Dashboard Analytics Start -->
            <section class="app-user-list">


                
                <div class="card">
                    <div style="margin: 10pt">
                        <div class="card-datatable table-responsive pt-0">
                            <div class="accordion" id="accutility" data-toggle-hover="true">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="utilityhead">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#utilityacc" aria-expanded="true" aria-controls="utilityacc">
                                        Tabel Nilai Utility
                                    </button>
                                    </h2>
                                    <div id="utilityacc" class="accordion-collapse collapse" aria-labelledby="utilityhead" data-bs-parent="#accordionMargin" style="">
                                    <div class="accordion-body">
                                        <table class="user-list-table table wptable" id="utilitytable">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>No.</th>
                                                    <th>Nama Sub-Kriteria</th>
                                                    <th>Bobot</th>
                                                    <th>Utility</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $kritdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="table-primary"><td colspan="4"><?php echo e($krit->nama); ?> || C<?php echo e($krit->id); ?> || (<?php echo e($krit->bobot); ?>)</td></tr>
                                                    <?php
                                                        $i = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $subkritdata->where('id_kriteria', $krit->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($i+1); ?></td>
                                                        <td><?php echo e($sub->nama); ?></td>
                                                        <td><?php echo e($sub->bobot); ?></td>
                                                        <td><?php echo e($subutil[$sub->id]); ?></td>
                                                    </tr>
                                                    <?php
                                                        $i += 1;
                                                    ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card">
                    <div style="margin: 10pt">
                        <div class="card-datatable table-responsive pt-0">
                            <div class="accordion" id="accordionExample" data-toggle-hover="true">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="penginputanhead">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#penginputanacc" aria-expanded="true" aria-controls="penginputanacc">
                                        Tabel Penginputan Nilai
                                        </button>
                                    </h2>
                                    <div id="penginputanacc" class="accordion-collapse collapse hide" aria-labelledby="penginputanhead" data-bs-parent="#accordionMargin" style="">
                                        <div class="accordion-body">
                                            <table class="user-list-table table wptable" id="inputtable">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Nama Alternatif</th>
                                                        <?php $__currentLoopData = $kritdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th>C<?php echo e($krit->id); ?> <?php echo e($krit->nama); ?></th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $kelasdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="
                                                        <?php if($kelas->tingkat == 10): ?>
                                                            table-primary
                                                        <?php elseif($kelas->tingkat == 11): ?>
                                                            table-success
                                                        <?php elseif($kelas->tingkat == 12): ?>
                                                            table-warning
                                                        <?php endif; ?>
                                                    "><td colspan="<?php echo e(2+$kritdata->count()); ?>">Kelas <?php echo e($kelas->tingkat); ?> <?php echo e($kelas->nama); ?></td></tr>
                                                        <?php $__currentLoopData = $alterdata->where('kelas', $kelas->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $alter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>A<?php echo e($i+1); ?></td>
                                                            <td><?php echo e($alter->nama); ?></td>
                                                            <?php $__currentLoopData = $kritdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <td><?php echo e($nilai[$krit->id][$alter->id]); ?></td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card">
                    <div style="margin: 10pt">
                        <div class="card-datatable table-responsive pt-0">
                            <div class="accordion" id="accordionExample" data-toggle-hover="true">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="normalisasihead">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#normalisasiacc" aria-expanded="true" aria-controls="normalisasiacc">
                                            Normalisasi Nilai Kriteria dan Nilai Utility
                                        </button>
                                    </h2>
                                    <div id="normalisasiacc" class="accordion-collapse collapse hide" aria-labelledby="normalisasihead" data-bs-parent="#accordionMargin" style="">
                                        <div class="accordion-body">
                                            <table class="user-list-table table wptable" id="normalisasitable">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Nama Alternatif</th>
                                                        <?php $__currentLoopData = $kritdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th>C<?php echo e($krit->id); ?> (<?php echo e($krit->nama); ?>)</th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $kelasdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="
                                                        <?php if($kelas->tingkat == 10): ?>
                                                            table-primary
                                                        <?php elseif($kelas->tingkat == 11): ?>
                                                            table-success
                                                        <?php elseif($kelas->tingkat == 12): ?>
                                                            table-warning
                                                        <?php endif; ?>
                                                    "><td colspan="<?php echo e(2+$kritdata->count()); ?>">Kelas <?php echo e($kelas->tingkat); ?> <?php echo e($kelas->nama); ?></td></tr>
                                                        <?php $__currentLoopData = $alterdata->where('kelas', $kelas->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $alter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>A<?php echo e($i+1); ?></td>
                                                            <td><?php echo e($alter->nama); ?></td>
                                                            <?php $__currentLoopData = $kritdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <td><?php echo e($normal[$krit->id][$alter->id]); ?></td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card">
                    <div style="margin: 10pt">
                        <div class="card-datatable table-responsive pt-0">
                            <div class="accordion" id="accordionExample" data-toggle-hover="true">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="nilaiakhirhead">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#nilaiakhiracc" aria-expanded="true" aria-controls="nilaiakhiracc">
                                            Nilai Akhir
                                        </button>
                                    </h2>
                                    <div id="nilaiakhiracc" class="accordion-collapse collapse" aria-labelledby="nilaiakhirhead" data-bs-parent="#accordionMargin" style="">
                                        <div class="accordion-body">
                                            <table class="user-list-table table wptable" id="nilaiakhirtable">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Nama Alternatif</th>
                                                        <?php $__currentLoopData = $kritdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th>C<?php echo e($krit->id); ?></th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <th>Nilai Akhir</th>
                                                        <th>Rank</th>
                                                        <th>Tingkat Keparahan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $kelasdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="
                                                        <?php if($kelas->tingkat == 10): ?>
                                                            table-primary
                                                        <?php elseif($kelas->tingkat == 11): ?>
                                                            table-success
                                                        <?php elseif($kelas->tingkat == 12): ?>
                                                            table-warning
                                                        <?php endif; ?>
                                                    "><td colspan="<?php echo e(5+$kritdata->count()); ?>">Kelas <?php echo e($kelas->tingkat); ?> <?php echo e($kelas->nama); ?></td></tr>
                                                        <?php $__currentLoopData = $alterdata->where('kelas', $kelas->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $alter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>A<?php echo e($i+1); ?></td>
                                                            <td><?php echo e($alter->nama); ?></td>
                                                            <?php $__currentLoopData = $kritdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <td><?php echo e($krithasil[$krit->id][$alter->id]); ?></td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <td><?php echo e($hasil[$alter->kelas][$alter->id]); ?></td>
                                                            <td><?php echo e($rankhasil[$alter->kelas][$alter->id]); ?></td>
                                                            <td><span class="
                                                                <?php if($labelhasil[$alter->kelas][$alter->id] == "Ringan"): ?>
                                                                    badge bg-success
                                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Sedang"): ?>
                                                                    badge bg-warning
                                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Berat"): ?>
                                                                    badge bg-danger
                                                                <?php else: ?>
                                                                    badge bg-secondary
                                                                <?php endif; ?>
                                                                "><?php echo e($labelhasil[$alter->kelas][$alter->id]); ?></span></td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card">
                    <div style="margin: 10pt">
                        <div class="card-datatable table-responsive pt-0">
                            <div class="accordion" id="accordionExample" data-toggle-hover="true">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="ranknilaiakhirhead">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#ranknilaiakhiracc" aria-expanded="true" aria-controls="ranknilaiakhiracc">
                                            Nilai Akhir (Berdasarkan Ranking)
                                        </button>
                                    </h2>
                                    <div id="ranknilaiakhiracc" class="accordion-collapse collapse" aria-labelledby="ranknilaiakhirhead" data-bs-parent="#accordionMargin" style="">
                                        <div class="accordion-body">
                                            <table class="user-list-table table wptable" id="ranknilaiakhirtable">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>No.</th>
                                                        <th>Nama Alternatif</th>
                                                        <?php $__currentLoopData = $kritdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th>C<?php echo e($krit->id); ?></th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <th>Nilai Akhir</th>
                                                        <th>Rank</th>
                                                        <th>Tingkat Keparahan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $kelasdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="
                                                        <?php if($kelas->tingkat == 10): ?>
                                                            table-primary
                                                        <?php elseif($kelas->tingkat == 11): ?>
                                                            table-success
                                                        <?php elseif($kelas->tingkat == 12): ?>
                                                            table-warning
                                                        <?php endif; ?>
                                                    "><td colspan="<?php echo e(5+$kritdata->count()); ?>">Kelas <?php echo e($kelas->tingkat); ?> <?php echo e($kelas->nama); ?></td></tr>
                                                        <?php $__currentLoopData = $alterdata->where('kelas', $kelas->id)->sortBy('rank'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $alter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>A<?php echo e($i+1); ?></td>
                                                            <td><?php echo e($alter->nama); ?></td>
                                                            <?php $__currentLoopData = $kritdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <td><?php echo e($krithasil[$krit->id][$alter->id]); ?></td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <td><?php echo e($hasil[$alter->kelas][$alter->id]); ?></td>
                                                            <td><?php echo e($rankhasil[$alter->kelas][$alter->id]); ?></td>
                                                            <td><span class="
                                                                <?php if($labelhasil[$alter->kelas][$alter->id] == "Ringan"): ?>
                                                                    badge bg-success
                                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Sedang"): ?>
                                                                    badge bg-warning
                                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Berat"): ?>
                                                                    badge bg-danger
                                                                <?php else: ?>
                                                                    badge bg-secondary
                                                                <?php endif; ?>
                                                                "><?php echo e($labelhasil[$alter->kelas][$alter->id]); ?></span></td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
            <?php if(session()->get('success')): ?>
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">Sukses</h4>
                <div class="alert-body">
                    <?php echo e(session('success')); ?>

                </div>
              </div>
            <?php elseif(session()->get('error')): ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error</h4>
                <div class="alert-body">
                    <?php echo e(session('error')); ?>

                </div>
              </div>
            <?php endif; ?>

        </div>
    </div>
</div>







<!-- END: Content-->
<?php echo $__env->make('app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script>

    $(document).ready(function(){
        const table = $('.wptable').DataTable({
            searching: false,
            paging: false,
            info: false,
        })
        });
</script>
<?php /**PATH /Users/erzxn/Documents/git/smarter/resources/views/auth/smarter.blade.php ENDPATH**/ ?>
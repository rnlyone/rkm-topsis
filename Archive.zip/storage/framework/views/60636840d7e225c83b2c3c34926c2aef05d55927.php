<?php echo $__env->make('app.app', ['hasil_active' => 'active', 'title' => 'Hasil Akhir'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">
            
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-start mb-0">Hasil Akhir Kelas <?php echo e($kelas->nama); ?></h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="/">Home</a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="/hasil">Hasil Akhir</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Dashboard Analytics Start -->
            <section class="app-user-list">

                <div class="card">
                    <div style="margin: 10pt">
                    <div class="card-datatable table-responsive pt-0">
                        <div class="card-header p-0">
                            <div class="head-label"><h5 class="mt-1">Hasil Kelas <?php echo e($kelas->nama); ?></h5></div>
                        </div>
                        <table class="user-list-table table" id="kelastable">
                            <thead class="table-light">
                                <tr>
                                    <th>Id.</th>
                                    <th>Nama</th>
                                    <th>Tingkat</th>
                                    <th>Rekomendasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $alterdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                        <td><?php echo e($alter->id); ?></td>
                                        <td><?php echo e($alter->nama); ?></td>
                                        <td><span class="
                                            <?php if($labelhasil[$alter->kelas][$alter->id] == "Ringan"): ?>
                                                badge bg-success
                                            <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Sedang"): ?>
                                                badge bg-warning
                                            <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Berat"): ?>
                                                badge bg-danger
                                            <?php else: ?>
                                                badge bg-secondary
                                            <?php endif; ?>
                                            "><?php echo e($labelhasil[$alter->kelas][$alter->id]); ?></span></td>
                                        <td>

                                        <span>
                                            <?php if(strpos($kelas->nama, "Tunanetra")!== false): ?>
                                                <?php if($labelhasil[$alter->kelas][$alter->id] == "Ringan"): ?>
                                                    MP. Audio Visual
                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Sedang"): ?>
                                                    MP. Visual
                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Berat"): ?>
                                                    MP. Audio
                                                <?php else: ?>
                                                Belum ada rekomendasi
                                                <?php endif; ?>
                                            <?php elseif(strpos($kelas->nama, "Tunarungu")!== false): ?>
                                                <?php if($labelhasil[$alter->kelas][$alter->id] == "Ringan"): ?>
                                                    MP. Audio
                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Sedang"): ?>
                                                    MP. Audio Visual
                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Berat"): ?>
                                                    MP. Visual
                                                <?php else: ?>
                                                Belum ada rekomendasi
                                                <?php endif; ?>
                                            <?php elseif(strpos($kelas->nama, "Tunadaksa")!== false): ?>
                                                <?php if($labelhasil[$alter->kelas][$alter->id] == "Ringan"): ?>
                                                    MP. Audio
                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Sedang"): ?>
                                                    MP. Visual
                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Berat"): ?>
                                                    MP. Audio Visual
                                                <?php else: ?>
                                                Belum ada rekomendasi
                                                <?php endif; ?>
                                            <?php elseif(strpos($kelas->nama, "Tunagrahita")!== false): ?>
                                                <?php if($labelhasil[$alter->kelas][$alter->id] == "Ringan"): ?>
                                                    MP. Audio
                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Sedang"): ?>
                                                    MP. Visual
                                                <?php elseif($labelhasil[$alter->kelas][$alter->id] == "Berat"): ?>
                                                    MP. Audio Visual
                                                <?php else: ?>
                                                    Belum ada rekomendasi
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </span>
                                        </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Modal to add new user starts-->

                    </div>
                    <!-- Modal to add new user Ends-->
                </div>

        </div>
    </div>
</div>







<!-- END: Content-->
<?php echo $__env->make('app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script>

    $(document).ready(function(){
        const table = $('.wptable').DataTable({
            searching: false,
            paging: false,
            info: false,
        })
        });
</script>
<?php /**PATH /Users/erzxn/Documents/git/smarter/resources/views/auth/hasilperkelas.blade.php ENDPATH**/ ?>
<?php echo $__env->make('app.app', ['dash_active' => 'active', 'title' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">
            <!-- Dashboard Analytics Start -->
            <section id="dashboard-analytics">
                <div class="row match-height">
                    <!-- Greetings Card starts -->
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="card card-congratulations">
                            <div class="card-body text-center">
                                <img src="/app-assets/images/elements/decore-left.png" class="congratulations-img-left"
                                    alt="card-img-left" />
                                <img src="/app-assets/images/elements/decore-right.png"
                                    class="congratulations-img-right" alt="card-img-right" />
                                <div class="avatar avatar-xl bg-primary shadow">
                                    <div class="avatar-content">
                                        <i data-feather="award" class="font-large-1"></i>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <h1 class="mb-1 text-white">Selamat Datang <?php echo e(auth()->user()->name); ?>,</h1>
                                    <p class="card-text m-auto w-75">
                                        Selamat datang di Aplikasi SMARTER, Penentuan Media Literasi Pembelajaran Anak Berkebutuhan Khusus Berbasis Web
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Greetings Card ends -->
                </div>

                <?php if(auth()->user()->role == 'admin'): ?>
                    
                    
                    
                    
                    
                    
                <?php endif; ?>


            </section>
            <!-- Dashboard Analytics end -->

        </div>
    </div>
</div>
<!-- END: Content-->

<?php echo $__env->make('app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/erzxn/Documents/git/smarter/resources/views/auth/dashboard.blade.php ENDPATH**/ ?>
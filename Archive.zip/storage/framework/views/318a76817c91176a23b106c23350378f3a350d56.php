<?php echo $__env->make('app.app', ['kriteria_active' => 'active', 'title' => 'Data Kriteria'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">
            
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-start mb-0">Data Kriteria</h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="/">Home</a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="Kriteria">Data Kriteria</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Dashboard Analytics Start -->
            <section class="app-user-list">
                <!-- list section start -->
                <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger" role="alert">
                    <h4 class="alert-heading">Error</h4>
                    <div class="alert-body">
                        <?php echo e($error); ?>

                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="card">
                    <div style="margin: 10pt">
                        <div class="card-datatable table-responsive pt-0">
                            <div class="card-header p-0">
                                <div class="head-label"><h5 class="mt-1">Tabel Data Kriteria</h5></div>
                                <div class="dt-action-buttons text-end">
                                    <button data-toggle="modal" data-bs-toggle="modal" data-bs-target="#tambah-kriteria" href="javascript:void(0)" class="btn btn-success" id="tombol-tambah">
                                        <i data-feather='plus'></i>
                                    </button>
                                </div>
                            </div>
                            <table class="user-list-table table" id="kriteriatable">
                                <thead class="table-light">
                                    <tr>
                                        <th>No.</th>
                                        <th>Kode</th>
                                        <th>Nama</th>
                                        <th>Prioritas</th>
                                        <th>Bobot</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- list section end -->
            </section>
            <?php if(session()->get('success')): ?>
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">Sukses</h4>
                <div class="alert-body">
                    <?php echo e(session('success')); ?>

                </div>
              </div>
            <?php elseif(session()->get('error')): ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error</h4>
                <div class="alert-body">
                    <?php echo e(session('error')); ?>

                </div>
              </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<!-- END: Content-->


<!-- Modal to add new user starts-->
<div class="modal fade text-start" id="tambah-kriteria" tabindex="-1" aria-labelledby="myModalLabel1"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Tambah Kriteria</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('kriteria.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <label>Id Kriteria: </label>
                    <div class="mb-1">
                        <input type="number" name="id" class="touchspin-min-max" value="<?php echo e($latestkriteria_id); ?>"/>
                    </div>

                    <label>Nama Kriteria: </label>
                    <div class="mb-1">
                        <input type="text" name="nama" placeholder="Nama Kriteria" value="<?php echo e(old('nama')); ?>" class="form-control" />
                    </div>

                    <label>Prioritas Kriteria: </label>
                    <div class="mb-1">
                        <input type="number" name="prioritas" class="touchspin-min-maxkrit" value="<?php echo e(old('prioritas') ?? '1'); ?>"/>
                    </div>

                    <label>Bobot Kriteria: </label>
                    <div class="mb-1">
                        <input type="text" name="bobot" class="touchspin" data-bts-step="0.01" data-bts-decimals="2" value="<?php echo e(old('bobot') ?? '0'); ?>" class="form-control" />
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Accept</button>
                </div>
            </form>
        </div>
    </div>
</div>
 <!-- Modal to add new user Ends-->


<?php $__currentLoopData = $kriteriadata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade text-start" id="modaledit<?php echo e($krd->id); ?>" tabindex="-1" aria-labelledby="myModalLabel1"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Edit Kriteria</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('kriteria.edit')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">

                    <label>Nama Kriteria: </label>
                    <div class="mb-1">
                        <input type="text" name="nama" placeholder="Nama Kriteria" value="<?php echo e($krd->nama); ?>" class="form-control" />
                    </div>

                    <label>Prioritas Kriteria: </label>
                    <div class="mb-1">
                        <input type="number" name="cur_prioritas" value="<?php echo e($krd->prioritas); ?>" hidden/>
                        <input type="number" name="prioritas" class="touchspin-min-maxkrit" value="<?php echo e($krd->prioritas); ?>"/>
                    </div>

                    <label>Bobot Kriteria: </label>
                    <div class="mb-1">
                        <input type="text" name="bobot" class="touchspin" data-bts-step="0.01" data-bts-decimals="2" value="<?php echo e($krd->bobot); ?>" class="form-control" />
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Accept</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $kriteriadata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade text-start modal-danger" id="modaldel<?php echo e($krd->id); ?>" tabindex="-1" aria-labelledby="myModalLabel140"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel140">Konfirmasi Hapus Kriteria</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apabila Kriteria dihapus, maka semua Sub-Kriteria dan Penilaian yang berhubungan dengan Kriteria tersebut akan terhapus, Yakin tetap menghapus?
            </div>
            <div class="modal-footer">
                <a href="kriteria/destroy/<?php echo e($krd->id); ?>" class="btn btn-danger">Ya</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php echo $__env->make('app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/forms/form-number-input.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

    $(document).ready(function(){
        const table = $('#kriteriatable').DataTable(
            {
                serverSide : true,
                processing : true,
                language : {
                    processing : "<div class='spinner-border text-primary' role='status'> <span class='visually-hidden'>Loading...</span></div>"
                },

                ajax : {
                    url: '<?php echo e(route('kriteria.index')); ?>',
                    type: 'GET'
                },

                columns : [
                    {data: 'id'},
                    {data: 'kode'},
                    {data: 'nama'},
                    {data: 'prioritas'},
                    {data: 'bobot'},
                    {data: 'action'}
                ],

                order: [[0, 'asc']],
                "drawCallback" : function( settings ) {
                    feather.replace();
                }
            })
        });
    </script>





<?php /**PATH /Users/erzxn/Documents/git/smarter/resources/views/auth/kriteria.blade.php ENDPATH**/ ?>
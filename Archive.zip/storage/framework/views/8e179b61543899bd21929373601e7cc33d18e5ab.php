<?php echo $__env->make('app.app', ['subkriteria_active' => 'active', 'title' => 'Data Sub-Kriteria'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
    use App\Models\Subkriteria;
?>
<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">
            
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-start mb-0">Data Sub-Kriteria</h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="/">Home</a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="Kriteria">Data Sub-Kriteria</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Dashboard Analytics Start -->
            <?php if(session()->get('success')): ?>
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">Sukses</h4>
                <div class="alert-body">
                    <?php echo e(session('success')); ?>

                </div>
              </div>
            <?php elseif(session()->get('error')): ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error</h4>
                <div class="alert-body">
                    <?php echo e(session('error')); ?>

                </div>
              </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger" role="alert">
                    <h4 class="alert-heading">Error</h4>
                    <div class="alert-body">
                        <?php echo e($error); ?>

                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php if($kriteriadata == $subsdata): ?>
            <div class="card">
                <div style="margin: 10pt">
                    <div class="card-datatable table-responsive pt-0">
                        <div class="card-header p-0">
                            <div class="head-label"><h5 class="mt-1">Tidak Ada Kriteria</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php $__currentLoopData = $kriteriadata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="app-user-list">
                <!-- list section start -->
                <div class="card">
                    <div style="margin: 10pt">
                        <div class="card-datatable table-responsive pt-0">
                            <div class="card-header p-0">
                                <div class="head-label"><h5 class="mt-1">Sub-Kriteria <?php echo e($krd->nama); ?> (C<?php echo e($krd->id); ?>)</h5></div>
                                <div class="dt-action-buttons text-end">
                                    <button data-toggle="modal" data-bs-toggle="modal" data-bs-target="#tambah-subkriteria<?php echo e($krd->id); ?>" href="javascript:void(0)" class="btn btn-success" id="tombol-tambah">
                                        <i data-feather='plus'></i>
                                    </button>
                                </div>
                            </div>
                            <table class="user-list-table table subTable" id="C<?php echo e($krd->id); ?>table">
                                <thead class="table-light">
                                    <tr>
                                        <th>No.</th>
                                        <th>Nama</th>
                                        <th>Prioritas</th>
                                        <th>Bobot</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $subdata = Subkriteria::where('id_kriteria', $krd->id)->get();

                                        $num = 1;
                                    ?>
                                    <?php $__currentLoopData = $subdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sbd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($num); ?></td>
                                            <td><?php echo e($sbd->nama); ?></td>
                                            <td><?php echo e($sbd->prioritas); ?></td>
                                            <td><?php echo e($sbd->bobot); ?></td>
                                            <td>
                                                <button data-toggle="modal" data-bs-toggle="modal" data-original-title="Edit" type="button" data-bs-target="#modaleditsub<?php echo e($sbd->id); ?>" type="button" class="edit-post btn btn-icon btn-success">
                                                    <i data-feather="edit-3"></i>
                                                </button>
                                                <button data-toggle="modal" data-bs-toggle="modal" name="delete" data-original-title="delete" data-bs-target="#modaldel<?php echo e($sbd->id); ?>" type="button" class="delete btn btn-icon btn-outline-danger">
                                                    <i data-feather="trash-2"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php
                                            $num++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="modal fade text-start" id="tambah-subkriteria<?php echo e($krd->id); ?>" tabindex="-1" aria-labelledby="myModalLabel1"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="myModalLabel1">Tambah Sub-Kriteria <?php echo e($krd->nama); ?> (C<?php echo e($krd->id); ?>)</h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('subkriteria.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <input type="text" name="id_kriteria" value="<?php echo e($krd->id); ?>" hidden>
                                    <label>Nama Sub-Kriteria: </label>
                                    <div class="mb-1">
                                        <input type="text" name="nama" placeholder="Nama Sub Kriteria" value="" class="form-control" />
                                    </div>

                                    <label>Prioritas Kriteria: </label>
                                    <div class="mb-1">
                                        <input type="number" name="prioritas" class="touchspin-min-maxkrit" value="<?php echo e($krd->prioritas); ?>"/>
                                    </div>

                                    <label>Bobot Sub-Kriteria: </label>
                                    <div class="mb-1">
                                        <input type="text" name="bobot" class="touchspin" data-bts-step="0.01" data-bts-decimals="2" value="0"/>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Accept</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- list section end -->
            </section>
            <?php $__currentLoopData = $subdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sbd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="modal fade text-start" id="modaleditsub<?php echo e($sbd->id); ?>" tabindex="-1" aria-labelledby="myModalLabel1"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel1">Edit Sub-Kriteria <?php echo e($sbd->nama); ?> | <?php echo e($krd->nama); ?> (C<?php echo e($krd->id); ?>)</h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="<?php echo e(route('subkriteria.edit')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <input type="text" name="idsub" value="<?php echo e($sbd->id); ?>" hidden>
                                <label>Nama Sub-Kriteria: </label>
                                <div class="mb-1">
                                    <input type="text" name="nama" placeholder="Nama Sub Kriteria" value="<?php echo e($sbd->nama); ?>" class="form-control" />
                                </div>
                                <label>Prioritas Kriteria: </label>
                                    <div class="mb-1">
                                        <input type="number" name="prioritas" class="touchspin-min-maxkrit" value="<?php echo e($sbd->prioritas); ?>"/>
                                    </div>
                                <label>Bobot Sub-Kriteria: </label>
                                    <div class="mb-1">
                                        <input type="text" name="bobot" class="touchspin" data-bts-step="0.01" data-bts-decimals="2" value="<?php echo e($sbd->bobot); ?>"/>
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Accept</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php if(session()->get('success')): ?>
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">Sukses</h4>
                <div class="alert-body">
                    <?php echo e(session('success')); ?>

                </div>
              </div>
            <?php elseif(session()->get('error')): ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error</h4>
                <div class="alert-body">
                    <?php echo e(session('error')); ?>

                </div>
              </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<!-- END: Content-->




<?php $__currentLoopData = $subsdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade text-start modal-danger" id="modaldel<?php echo e($skd->id); ?>" tabindex="-1" aria-labelledby="myModalLabel140"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel140">Konfirmasi Hapus Kriteria</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apabila Kriteria dihapus, maka semua Sub-Kriteria dan Penilaian yang berhubungan dengan Kriteria tersebut akan terhapus, Yakin tetap menghapus?
            </div>
            <div class="modal-footer">
                <a href="subkriteria/destroy/<?php echo e($skd->id); ?>" class="btn btn-danger">Ya</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





<?php echo $__env->make('app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/forms/form-number-input.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready( function () {
            $('.subTable').DataTable();
        } );
    </script>




<?php /**PATH /Users/erzxn/Documents/git/smarter/resources/views/auth/subkriteria.blade.php ENDPATH**/ ?>
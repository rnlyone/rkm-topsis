<?php echo $__env->make('app.app', ['kelas_active' => 'active', 'title' => 'Data Kelas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">
            
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-start mb-0">Data Kelas</h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="/">Home</a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="kelas">Data Kelas</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Dashboard Analytics Start -->
            <section class="app-user-list">
                <!-- list section start -->
                <div class="card">
                    <div style="margin: 10pt">
                    <div class="card-datatable table-responsive pt-0">
                        <div class="card-header p-0">
                            <div class="head-label"><h5 class="mt-1">Tabel Data Kelas</h5></div>
                            <div class="dt-action-buttons text-end">
                                <button data-toggle="modal" data-bs-toggle="modal" data-bs-target="#tambah-kelas" href="javascript:void(0)" class="btn btn-success" id="tombol-tambah">
                                    <i data-feather='plus'></i>
                                </button>
                            </div>
                        </div>
                        <table class="user-list-table table" id="kelastable">
                            <thead class="table-light">
                                <tr>
                                    <th>No.</th>
                                    <th>Tingkat</th>
                                    <th>Nama Kelas</th>
                                    <th>Wali Kelas</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <!-- Modal to add new user starts-->

                    </div>
                    <!-- Modal to add new user Ends-->
                </div>
                <!-- list section end -->
            </section>
            <?php if(session()->get('success')): ?>
            <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">Sukses</h4>
                <div class="alert-body">
                    <?php echo e(session('success')); ?>

                </div>
              </div>
            <?php elseif(session()->get('error')): ?>
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Error</h4>
                <div class="alert-body">
                    <?php echo e(session('error')); ?>

                </div>
              </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger" role="alert">
                    <h4 class="alert-heading">Error</h4>
                    <div class="alert-body">
                        <?php echo e($error); ?>

                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
        </div>
    </div>
</div>


<?php $__currentLoopData = $kelasdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ald): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade text-start" id="modaledit<?php echo e($ald->id); ?>" tabindex="-1" aria-labelledby="myModalLabel1"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Edit Kelas</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="kelas/edit" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <label>Id Kelas: </label>
                    <div class="mb-1">
                        <input type="number" name="id" class="touchspin-min-max" value="<?php echo e($ald->id); ?>"/>
                    </div>

                    <input type="text" name="idedit" value="<?php echo e($ald->id); ?>" hidden>

                    <label>Tingkat Kelas: </label>
                    <div class="mb-1">
                        <select name="tingkat" class="form-select" id="basicSelect" required>
                        <option value="">Pilih Tingkat</option>
                          <option value="10" <?php if($ald->tingkat == 10): ?> selected='selected' <?php endif; ?>>10 (Tingkat Sepuluh)</option>
                          <option value="11" <?php if($ald->tingkat == 11): ?> selected='selected' <?php endif; ?>>11 (Tingkat Sebelas)</option>
                          <option value="12" <?php if($ald->tingkat == 12): ?> selected='selected' <?php endif; ?>>12 (Tingkat Dua Belas)</option>
                        </select>
                    </div>

                    <label>Nama Kelas: </label>
                    <div class="mb-1">
                        <input type="text" name="nama" placeholder="Nama Kelas" value="<?php echo e($ald->nama); ?>" class="form-control" />
                    </div>

                    <label>Wali Kelas: </label>
                    <div class="mb-1">
                        <select name="walikelas" class="form-select" id="basicSelect" required>
                        <option value="">Pilih User</option>
                        <?php $__currentLoopData = $walikelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($wk->id); ?>" <?php if($ald->walikelas == $wk->id): ?> selected='selected' <?php endif; ?>><?php echo e($wk->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Accept</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $kelasdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ald): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade text-start modal-danger" id="modaldel<?php echo e($ald->id); ?>" tabindex="-1" aria-labelledby="myModalLabel140"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel140">Konfirmasi Hapus Kelas</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apabila Dihapus, Semua Penilaian yang berkaitan dengan kelas tersebut akan dihapus, tetap Hapus?
            </div>
            <div class="modal-footer">
                <a href="kelas/destroy/<?php echo e($ald->id); ?>" class="btn btn-danger">Ya</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Modal to add new user starts-->
<div class="modal fade text-start" id="tambah-kelas" tabindex="-1" aria-labelledby="myModalLabel1"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1">Tambah Kelas</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('kelas.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <label>Id Kelas: </label>
                    <div class="mb-1">
                        <input type="number" name="id" class="touchspin-min-max" value="<?php echo e($latestkelas_id+1); ?>"/>
                    </div>

                    <label>Tingkat Kelas: </label>
                    <div class="mb-1">
                        <select name="tingkat" class="form-select" id="basicSelect" required>
                        <option value="">Pilih Tingkat</option>
                          <option value="10">10 (Tingkat Sepuluh)</option>
                          <option value="11">11 (Tingkat Sebelas)</option>
                          <option value="12">12 (Tingkat Dua Belas)</option>
                        </select>
                    </div>

                    <label>Nama Kelas: </label>
                    <div class="mb-1">
                        <input type="text" name="nama" placeholder="Nama Kelas" value="<?php echo e(old('nama')); ?>" class="form-control" />
                    </div>

                    <label>Wali Kelas: </label>
                    <div class="mb-1">
                        <select name="walikelas" class="form-select" id="basicSelect" required>
                        <option value="">Pilih User</option>
                        <?php $__currentLoopData = $walikelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($wk->id); ?>"><?php echo e($wk->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Accept</button>
                </div>
            </form>
        </div>
    </div>
</div>
 <!-- Modal to add new user Ends-->




<!-- END: Content-->
<?php echo $__env->make('app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/forms/form-number-input.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

    $(document).ready(function(){
        const table = $('#kelastable').DataTable(
            {
                serverSide : true,
                processing : true,
                language : {
                    processing : "<div class='spinner-border text-primary' role='status'> <span class='visually-hidden'>Loading...</span></div>"
                },

                ajax : {
                    url: '<?php echo e(route('kelas.index')); ?>',
                    type: 'GET'
                },

                columns : [
                    {data: 'id'},
                    {data: 'tingkat'},
                    {data: 'nama'},
                    {data: 'namawalikelas'},
                    {data: 'action'}
                ],

                order: [[0, 'asc']],
                "drawCallback" : function( settings ) {
                    feather.replace();
                }
            })
        });
</script>
<?php /**PATH /Users/erzxn/Documents/git/smarter/resources/views/auth/kelas.blade.php ENDPATH**/ ?>
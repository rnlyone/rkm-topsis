<?php

namespace App\Http\Controllers;

use App\Models\Alternatif;
use App\Models\Kelas;
use App\Models\Kriteria;
use App\Models\Penilaian;
use App\Models\Subkriteria;
use App\Models\User;
use Illuminate\Http\Request;

class SmarterController extends Controller
{
    function array_rank( $in ) {
        $x = $in; arsort($x);
        $rank       = 0;
        $hiddenrank = 0;
        $hold = null;
        foreach ( $x as $key=>$val ) {
            $hiddenrank += 1;
            $rank = $hiddenrank;
            if ( is_null($hold) || $val < $hold ) {
                $hold = $val;
            }
            $in[$key] = $rank;
        }
        return $in;
        }

        function reverse_rank( $in ) {
            $k = array_keys($in);
            $v = array_values($in);

            $rv = array_reverse($v);

            $b = array_combine($k, $rv);

            return $b;
        }

        public function smarter()
        {
            $user = User::where('role', 'guru')->get();
            $alterdata = Alternatif::all();
            $kritdata = Kriteria::all();
            $subkritdata = Subkriteria::all();
            $nilaidata = Penilaian::all();
            $kelasdata = Kelas::all();

            #perhitungan nilai utility setiap subkriteria
            foreach ($subkritdata as $j => $sub) {
                $bobotkrit = $kritdata->where('id', $sub->id_kriteria)->first()->bobot;
                $subutil[$sub->id] = $sub->bobot * $bobotkrit;
            }

            #Normalisasi Nilai Kriteria & Nilai Utility

            foreach ($kritdata as $i => $krit) {
                $cmax = Subkriteria::where('id_kriteria', $krit->id)->get()->max('bobot');
                $cmin = Subkriteria::where('id_kriteria', $krit->id)->get()->min('bobot');
                foreach ($alterdata as $j => $alter) {
                    # =(100%*(peniliaian-cmin)/(cmax-cmin))
                    try {
                        $subkrit = Penilaian::where(['id_alternatif' => $alter->id, 'id_kriteria' => $krit->id])->first()->id_subkriteria;
                        // $subkrit = Penilaian::where(['id_alternatif', '=', $alter->id], ['id_kriteria', '=', $krit->subkrit])->first()->id_subkriteria;
                        $nilai[$krit->id][$alter->id] = Subkriteria::where('id', $subkrit)->first()->bobot;
                        $normal[$krit->id][$alter->id] = (1*($nilai[$krit->id][$alter->id]-$cmin)/($cmax-$cmin));

                        // if ($alter->id == 5) {
                        //     dd($normal);
                        // }

                    } catch (\Throwable $th) {
                        $subkrit = null;
                        $nilai[$krit->id][$alter->id] = null;
                        $normal[$krit->id][$alter->id] = null;
                    }
                }
            }
            // dd($nilai);


            #Hasil Akhir
            foreach ($kritdata as $i => $krit) {
                foreach ($alterdata as $j => $alter) {
                    try {
                        $krithasil[$krit->id][$alter->id] = $krit->bobot * $normal[$krit->id][$alter->id];
                    } catch (\Throwable $th) {
                        $krithasil[$krit->id][$alter->id] = null;
                    }
                }
            }
            // dd($krithasil);


            #penjumlahan nilai akhir
            foreach ($alterdata as $j => $alter) {
                $hasil[$alter->kelas][$alter->id] = 0;
                foreach ($kritdata as $i => $krit) {
                    try {
                        $hasil[$alter->kelas][$alter->id] = $hasil[$alter->kelas][$alter->id] + $krithasil[$krit->id][$alter->id];
                    } catch (\Throwable $th) {
                        $hasil[$alter->kelas][$alter->id] = null;
                    }
                }
            }
            // dd($hasil);

        #ranking hasil akhir &
        $rankhasil[1] = 0;
        foreach ($kelasdata as $i => $kelas) {
            try {
                $rankhasil[$kelas->id] = SmarterController::array_rank($hasil[$kelas->id]);
            } catch (\Throwable $th) {
                $rankhasil[$kelas->id] = 0;
            }
        }
        // dd($hasil, $rankhasil);

        #labeling hasil akhir
        foreach ($alterdata as $j => $alter) {
            try {
                if ($hasil[$alter->kelas][$alter->id] >= 0.6) {
                    $labelhasil[$alter->kelas][$alter->id] = "Ringan";
                } elseif ($hasil[$alter->kelas][$alter->id] >= 0.4 && $hasil[$alter->kelas][$alter->id] <= 0.59) {
                    $labelhasil[$alter->kelas][$alter->id] = "Sedang";
                } elseif($hasil[$alter->kelas][$alter->id] < 0.4 && $hasil[$alter->kelas][$alter->id] > 0) {
                    $labelhasil[$alter->kelas][$alter->id] = "Berat";
                } elseif ($hasil[$alter->kelas][$alter->id] == 0) {
                    $labelhasil[$alter->kelas][$alter->id] = "Null";
                }
            } catch (\Throwable $th) {
                $labelhasil[$alter->kelas][$alter->id] = "Undefined";
            }
        }
        // dd($normal, $hasil, $rankhasil, $labelhasil);
        // asort($rankhasil[2]);
        // $rankhasil = (object) $rankhasil;
        $alterdata;

        foreach ($alterdata as $i => $alter) {
            $alter->setAttribute('rank', $rankhasil[$alter->kelas][$alter->id]);
        }

        return view('auth.smarter', ['alterdata' => $alterdata,
        'kritdata' =>  $kritdata,
        'krithasil' => $krithasil,
        'subkritdata' => $subkritdata,
        'nilai' => $nilai,
        'normal' => $normal,
        'hasil' => $hasil,
        'rankhasil' => $rankhasil,
        'labelhasil' => $labelhasil,
        'subutil' => $subutil,
        'kelasdata' => $kelasdata]);

        }

    public function indexsmarter()
    {
        return view('auth.smarter', [
            'alterdata' => SmarterController::smarter()->alterdata,
            'kritdata' => SmarterController::smarter()->kritdata,
            'krithasil' => SmarterController::smarter()->krithasil,
            'subkritdata' => SmarterController::smarter()->subkritdata,
            // 'nilaidata' => SmarterController::smarter()->nilaidata,
            'normal' => SmarterController::smarter()->normal,
            'hasil' => SmarterController::smarter()->hasil,
            'rankhasil' => SmarterController::smarter()->rankhasil,
            'labelhasil' => SmarterController::smarter()->labelhasil,
            'subutil' => SmarterController::smarter()->subutil,
            'nilai' => SmarterController::smarter()->nilai,
            'kelasdata' => SmarterController::smarter()->kelasdata
        ]);
    }

    public function indexHasil()
    {
        return view('auth.hasil', [
            'alterdata' => SmarterController::smarter()->alterdata,
            'kritdata' => SmarterController::smarter()->kritdata,
            'krithasil' => SmarterController::smarter()->krithasil,
            'subkritdata' => SmarterController::smarter()->subkritdata,
            // 'nilaidata' => SmarterController::smarter()->nilaidata,
            'normal' => SmarterController::smarter()->normal,
            'hasil' => SmarterController::smarter()->hasil,
            'rankhasil' => SmarterController::smarter()->rankhasil,
            'labelhasil' => SmarterController::smarter()->labelhasil,
            'subutil' => SmarterController::smarter()->subutil,
            'nilai' => SmarterController::smarter()->nilai,
            'kelasdata' => SmarterController::smarter()->kelasdata
        ]);
    }

    public function
    hasilKelas($id)
    {
        $alterdata = Alternatif::where('kelas', $id)->get();
        $kelas = Kelas::where('id', $id)->first();
        return view('auth.hasilperkelas', [
            'alterdata' => $alterdata,
            'kelas' => $kelas,
            'labelhasil' => SmarterController::smarter()->labelhasil,
        ]);
    }
}

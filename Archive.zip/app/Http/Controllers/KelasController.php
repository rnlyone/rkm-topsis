<?php

namespace App\Http\Controllers;

use App\Models\Alternatif;
use App\Models\Kelas;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class KelasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (auth()->user()->role == 'guru'){
            return abort(403, 'Maaf, Halaman Ini Bukan Untuk Anda');
        }

        $kelasdata = Kelas::all();
        $walikelas = User::where('role', 'guru')->get();

        if ($request->ajax()){
            return DataTables::of($kelasdata)
            ->addColumn('action', function($data){
                $button = '
                <button data-toggle="modal" data-bs-toggle="modal" data-original-title="Edit" type="button" data-bs-target="#modaledit'.$data->id.'" type="button" class="edit-post btn btn-icon btn-success">
                    <i data-feather="edit-3"></i>
                </button>';
                // $button .= '&nbsp;&nbsp;';
                $button .= '
                <button data-toggle="modal" data-bs-toggle="modal" name="delete" data-original-title="delete" data-bs-target="#modaldel'.$data->id.'" type="button" class="delete btn btn-icon btn-outline-danger">
                    <i data-feather="trash-2"></i>
                </button>';
                return $button;
            })
            ->addColumn('namawalikelas', function($data){
                $walikelas = User::where('id', $data->walikelas)->first()->name;

                return $walikelas;
            })
            ->addColumn('aksihasil', function($data){
                $button = '
                <a href="hasil/'.$data->id.'" class="edit-post btn btn-icon btn-success">
                    <i data-feather="edit-3"></i>
                </a>';
                return $button;
            })
            ->rawColumns(['action', 'namawalikelas', 'aksihasil'])
            ->addIndexColumn()
            ->make(true);
        }

        try {
            $latestkelas_id = Kelas::latest()->first()->id;
        } catch (\Throwable $th) {
            $latestkelas_id = 0;
        }


        return view('auth.kelas', ['kelasdata' => $kelasdata, 'latestkelas_id' => $latestkelas_id, 'walikelas' => $walikelas]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
        $req->validate([
            'id' => [
                'unique:App\Models\Kelas,id',
                'required'
            ],
            'nama' => [
                // 'unique:App\Models\Kelas,nama',
                'required'
            ]
        ]);

        // if($req->tingkat == Kelas::where('tingkat', $req->tingkat)->first()->tingkat &&
        //    $req->nama == Kelas::where('nama', $req->nama)->first()->nama){
        //     return back()->with('error', 'Kelas Sudah Ada');
        // }

        try {
            Kelas::create([
                'id' => $req->id,
                'tingkat' => $req->tingkat,
                'nama' => $req->nama,
                'walikelas' => $req->walikelas
            ]);
            return back()->with('success', 'Kelas Berhasil Dibuat.');
        } catch (Exception $e) {
            return back()->with('error', 'Maaf, Terdapat Kesalahan', $e);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function show(Kelas $kelas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function edit(Kelas $kelas)
    {
        //
    }

    public function editkelas(Request $req)
    {
        $req->validate([
            'id' => [
                'unique:App\Models\Kelas,id,'. $req->idedit,
                'required'
            ],
            'nama' => [
                // 'unique:App\Models\Kelas,nama',
                'required'
            ]
        ]);

        try {
            Kelas::where('id', $req->idedit)->update([
                'id' => $req->id,
                'nama' => $req->nama,
                'tingkat' => $req->tingkat,
                'walikelas' => $req->walikelas
            ]);
            return back()->with('success', 'Kelas Berhasil Diedit.');
        } catch (Exception $e) {
            return back()->with('error', 'Maaf, Kelas Gagal Diedit');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kelas $kelas)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kelas  $kelas
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Alternatif::where('kelas', $id)->delete();
        Kelas::where('id', $id)->delete();
        return back()->with('success', 'Kelas Berhasil Dihapus.');
    }
}

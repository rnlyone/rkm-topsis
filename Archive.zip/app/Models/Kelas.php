<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kelas extends Model
{
    use HasFactory;

    protected $fillable = [
        'id',
        'tingkat',
        'nama',
        'walikelas'
    ];

    public function user()
    {
        return $this->belongsTo('App\Models\User','id');
    }

    public function alternatif()
    {
        return $this->hasMany('App\Models\Alternatif', 'id');
    }
}
